# train_ppo.py
from __future__ import annotations

import os
import json
import time
import random
import signal
from pathlib import Path
from dataclasses import asdict, replace
from typing import Iterator, Optional, Dict, Any

import numpy as np

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.utils import set_random_seed

# ---- project imports ----
from utils.data_loader import load_all_ready
from rl.episodes import iter_episodes, TripPlan
from rl.ppo_env import PPOChargingEnv, PPOEnvConfig


# Trip iterator
def make_trip_iterator(sim_csv: Path, seed: int) -> Iterator[TripPlan]:
    rng = np.random.default_rng(seed)
    while True:
        episodes = list(iter_episodes(sim_csv))
        if not episodes:
            raise RuntimeError(f"No episodes found in {sim_csv}")
        idx = np.arange(len(episodes))
        rng.shuffle(idx)
        for i in idx:
            yield episodes[i]


# Env wrapper
class PPOTripEnv(PPOChargingEnv):
    def __init__(self, cfg: PPOEnvConfig, bundle: Dict[str, Any], trip_iter: Iterator[TripPlan]):
        super().__init__(cfg, data_bundle=bundle)
        self._trip_iter = trip_iter

    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        trip = next(self._trip_iter)
        return super().reset(seed=seed, options={"trip": trip})


# KPI logger
class EpisodeKpiLogger(BaseCallback):
    def __init__(self, log_csv: Path, verbose: int = 0):
        super().__init__(verbose)
        self.log_csv = Path(log_csv)
        self._header_written = False

    def _on_training_start(self) -> None:
        self.log_csv.parent.mkdir(parents=True, exist_ok=True)

    def _on_step(self) -> bool:
        import numpy as np, time
        dones = self.locals.get("dones", [])
        infos = self.locals.get("infos", [])
        if not isinstance(dones, (list, tuple, np.ndarray)) or not dones:
            return True
        for done, info in zip(dones, infos):
            if not done:
                continue
            row = {
                "time_s": int(time.time()),
                "timesteps": int(self.num_timesteps),
                "episode_steps": int(info.get("episode_steps", -1)),
                "total_minutes": float(info.get("episode_minutes", 0.0)),
                "total_cost_gbp": float(info.get("episode_cost_gbp", 0.0)),
                "success": int(float(info.get("remaining_km", 1.0)) <= 0.0),
                "stranded": int(float(info.get("soc_final", 1.0)) <= 0.0),
                "soc_final": float(info.get("soc_final", -1.0)),
                "remaining_km": float(info.get("remaining_km", -1.0)),
                "charge_events": int(info.get("charge_events", 0)),
                "termination_reason": info.get("termination_reason", "unknown"),
                "violations_repeat": int(info.get("violations_repeat", 0)),
                "violations_overlimit": int(info.get("violations_overlimit", 0)),
                "violations_cooldown": int(info.get("violations_cooldown", 0)),
                "reward_progress": float(info.get("reward_progress", 0.0)),
                "penalty_dither": float(info.get("penalty_dither", 0.0)),
            }
            write_header = (not self._header_written) or (not self.log_csv.exists())
            with self.log_csv.open("a", encoding="utf-8") as f:
                import csv
                writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                if write_header:
                    writer.writeheader()
                    self._header_written = True
                writer.writerow(row)
        return True


# Env factory
def make_env(bundle, trip_iter, cfg: PPOEnvConfig, log_dir: Path, seed: int):
    def _thunk():
        env = PPOTripEnv(cfg, bundle, trip_iter)
        env = Monitor(env, filename=str(log_dir / "monitor.csv"), allow_early_resets=True)
        env.reset(seed=seed)
        return env
    return _thunk


# Microsim eval config
def cfg_for_eval_microsim(cfg: PPOEnvConfig) -> PPOEnvConfig:
    return replace(cfg, sumo_mode="microsim", traffic_mode="none", sumo_gui=False)


# Sequential evaluation
def evaluate_model_sequential(model, make_env_eval, n_episodes: int, out_csv: Path, deterministic: bool = True):
    import csv
    out_csv = Path(out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "episode","minutes","cost_gbp","steps","charge_events","soc_final",
        "remaining_km","termination_reason","violations_repeat","violations_overlimit",
        "violations_cooldown","reward_progress","penalty_dither"
    ]
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for ep in range(1, n_episodes + 1):
            env = make_env_eval()
            try:
                obs, _ = env.reset()
                done, last_info = False, {}
                while not done:
                    action, _ = model.predict(obs, deterministic=deterministic)
                    obs, reward, terminated, truncated, info = env.step(action)
                    done = bool(terminated or truncated)
                    last_info = info
            finally:
                env.close()
            kpi = last_info or {}
            row = {
                "episode": ep,
                "minutes": kpi.get("episode_minutes"),
                "cost_gbp": kpi.get("episode_cost_gbp"),
                "steps": kpi.get("episode_steps"),
                "charge_events": kpi.get("charge_events"),
                "soc_final": kpi.get("soc_final"),
                "remaining_km": kpi.get("remaining_km"),
                "termination_reason": kpi.get("termination_reason"),
                "violations_repeat": kpi.get("violations_repeat"),
                "violations_overlimit": kpi.get("violations_overlimit"),
                "violations_cooldown": kpi.get("violations_cooldown"),
                "reward_progress": kpi.get("reward_progress"),
                "penalty_dither": kpi.get("penalty_dither"),
            }
            writer.writerow(row)
    print(f"[EVAL] Wrote {n_episodes} episodes → {out_csv}")
    return out_csv


def main():
    project_root = Path(".").resolve()
    data_dir = project_root / "data"
    sim_csv = data_dir / "sim_users_train_calibrated.csv"
    eval1_csv = data_dir / "sim_users_eval_calibrated.csv"

    EXPERIMENT = "A"
    seed = 202
    RUN_TAG = "Hatim_train_dt10_topk5_light_singleenv"
    TOTAL_STEPS = 500_000

    run_name = time.strftime(f"ppo_ev_%Y%m%d_%H%M%S_{RUN_TAG}")
    out_dir = project_root / "runs" / run_name
    tb_log_dir = out_dir / "tb"
    kpi_csv = out_dir / "kpi_episodes.csv"
    model_final_path = out_dir / "model_final.zip"
    out_dir.mkdir(parents=True, exist_ok=True)

    set_random_seed(seed)
    random.seed(seed)
    np.random.seed(seed)
    import torch
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    cfg = PPOEnvConfig(
        obs_top_k=5,
        dt_minutes=10.0,
        max_steps=84,
        prefer="hybrid",
        value_of_time_per_min=0.05,
        charge_efficiency=0.92,
        charge_session_overhead_min=3.0,
        traffic_mode="light",
        traffic_peak_factor_am=1.6,
        traffic_peak_factor_pm=1.5,
        traffic_offpeak_factor=1.0,
        use_sumo_drive=True,
        sumo_net_path=str((Path(".") / "london_inner.net.xml").resolve()),
        sumo_gui=False,
        sumo_step_length_s=1.0,
        sumo_mode="route_time",
        sumo_vehicle_type="passenger",
        enable_progress_shaping=True,
        progress_scale=0.4,
        progress_normalizer_km=1.0,
        enable_anti_dither=True,
        anti_dither_min_progress_km=0.05,
        anti_dither_penalty=-0.1,
        disallow_repeat_station=True,
        max_charges_per_trip=2,
        min_charge_gap_min=12.0,
        penalty_repeat=-5.0,
        penalty_overlimit=-20.0,
        penalty_cooldown=-5.0,
        terminate_on_overlimit=True,
    )

    bundle = load_all_ready(data_dir, strict=True)
    trip_iter = make_trip_iterator(sim_csv, seed)
    env_fn = make_env(bundle, trip_iter, cfg, out_dir, seed)
    vec_env = DummyVecEnv([env_fn])

    policy_kwargs = dict(
        net_arch=dict(pi=[256, 256], vf=[256, 256]),
        activation_fn=torch.nn.Tanh,
        ortho_init=True,
    )

    def lr_schedule(frac): return 3e-4 * frac
    def clip_schedule(frac): return 0.2 * frac + 0.05

    model = PPO(
        policy="MlpPolicy",
        env=vec_env,
        verbose=1,
        tensorboard_log=str(tb_log_dir),
        n_steps=4096,
        batch_size=2048,
        learning_rate=lr_schedule,
        gamma=0.997,
        gae_lambda=0.95,
        clip_range=clip_schedule,
        ent_coef=0.02,
        vf_coef=0.7,
        max_grad_norm=0.5,
        device="auto",
        seed=seed,
        policy_kwargs=policy_kwargs,
    )

    ckpt_cb = CheckpointCallback(
        save_freq=50_000,
        save_path=str(out_dir / "ckpts"),
        name_prefix=RUN_TAG
    )
    kpi_cb = EpisodeKpiLogger(kpi_csv)

    stop_training = {"flag": False}
    def _sigint_handler(sig, frame):
        print("\n[train] Caught Ctrl+C — stopping after current update…")
        stop_training["flag"] = True
    signal.signal(signal.SIGINT, _sigint_handler)

    rolled = 0
    while rolled < TOTAL_STEPS and not stop_training["flag"]:
        chunk = min(50_000, TOTAL_STEPS - rolled)
        model.learn(total_timesteps=chunk, reset_num_timesteps=False, callback=[kpi_cb, ckpt_cb], progress_bar=True)
        rolled += chunk
        print(f"[train] progress {rolled}/{TOTAL_STEPS}")

    model.save(str(model_final_path))
    print(f"[train] final model → {model_final_path}")

    try:
        vec_env.envs[0].unwrapped.close()
    except Exception:
        pass
    vec_env.close()

    # Sequential evaluation
    EVAL_MICROSIM = True
    EVAL_EPISODES = 50 if EVAL_MICROSIM else 100
    eval_cfg = cfg_for_eval_microsim(cfg) if EVAL_MICROSIM else cfg
    def make_env_eval():
        eval_iter = make_trip_iterator(eval1_csv, seed)
        return make_env(bundle, eval_iter, eval_cfg, out_dir, seed)()
    model = PPO.load(str(model_final_path), device="auto")
    eval_suffix = "microsim" if EVAL_MICROSIM else "route_time"
    eval_csv = out_dir / f"eval_sequential_{eval_suffix}.csv"
    evaluate_model_sequential(model, make_env_eval, n_episodes=EVAL_EPISODES, out_csv=eval_csv, deterministic=True)
    print(f"[done] training + evaluation complete. KPIs: {kpi_csv} | Eval({eval_suffix}): {eval_csv}")


if __name__ == "__main__":
    main()
